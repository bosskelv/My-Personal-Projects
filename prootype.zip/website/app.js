const projectsList = document.querySelector('.projects ul');


// Example usage
createProject('Project Alpha', 'Website Redesign', 'In Progress');
createProject('Project Beta', 'Plan Summer Vacation', 'Not Started');
<script>
  const btn = document.querySelector('.btn-primary');
  btn.addEventListener('click', function() {
    btn.style.backgroundColor = 'green'
  });
</script>